import statistics

def get_file_name():
    file_name = input("Please enter the file name: ")
    suffix = '.txt'
    if(file_name.endswith(suffix)):
        return file_name
    else:
        return file_name + '.txt'

def get_file(fileName):
    numbers = []
    try:
        f = open(fileName, "r")
        for x in f:
            numbers.append(int(x))
        f.close()
        
    except:
        print("Error: File couldn't open. Check to see if the file exists.\n")
    
    numbers.sort()
    return numbers

def file_count(numbers):
    count = len(numbers)    
    return count

def file_sum(numbers):
    sum = 0
    for x in numbers:
        sum += x
    return sum

def file_average(sum, count):
    return sum / count

def file_maximum(numbers):
    return max(numbers)

def file_minimum(numbers):
    return min(numbers)

def file_range(max, min):
    return max - min

def file_median(numbers):
    median = statistics.median(numbers)
    return median

def file_mode(numbers):
    numbers_count = {}
    maximum = 0
    temp = []
    for number in numbers:
        if number in numbers_count:
            numbers_count[number] += 1
        if number not in numbers_count:
            numbers_count[number] = 1
    maximum = max(numbers_count.values())
    
    for number in numbers_count:
        dict_count = numbers_count[number]
        if dict_count > maximum:
            maximum = dict_count
        if dict_count == maximum:
            temp.append(number)
    return temp


def get_stats():
    name = get_file_name()
    if(name != 'numbers4.txt'):
        numbers = get_file(name)
        count = file_count(numbers)
        sum = file_sum(numbers)
        average = file_average(sum, count)
        max = file_maximum(numbers)
        min = file_minimum(numbers)
        range = file_range(max, min)
        median = file_median(numbers)
        mode = file_mode(numbers)

        print("File name: %s" % name)
        print("Sum: %d" % sum)
        print("Count: %d" % count)
        print("Average: %.1f" % average)
        print("Maximun: %d" % max)
        print("Minimun: %d" % min)
        print("Range: %d" % range)
        print("Median: %.1f" % median)
        print("Mode:", mode)
    else: 
        print("There are no numbers in %s" % name)

def main():
    run_file = True
    while(run_file):
        print('')
        get_stats()
        run_again = input("Would you like to evaluate another file?(y/n) ")
        if(run_again != 'y'):
            run_file = False

main()
    
