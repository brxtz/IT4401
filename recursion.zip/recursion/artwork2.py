import random
from turtle import Turtle

def recursive_circles(turtle, angle, length, delta):
    colors = ["yellow", "green", "purple", "orange", "blue", "red", "black"]
    color = random.choice(colors) 
    turtle.color(color)
    turtle.right(angle)
    turtle.forward(length)
    length = length - delta
    angle = angle + 25
    if(length > 2):
        recursive_circles(turtle, angle, length, delta)

def main():
    ANIMATION_SPEED = 0.0
    raphael = Turtle()
    raphael.speed(ANIMATION_SPEED)
    recursive_circles(raphael, 0, 500, 1)

main()