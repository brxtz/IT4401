import random
from turtle import Turtle

def recursive_circles(turtle, angle, length, quantity, delta, radius):
    colors = ["yellow", "green", "purple", "orange", "blue", "red", "black"]
    color = random.choice(colors)
    #turtle.penup()
    turtle.color(color)
    turtle.right(angle)
    turtle.forward(delta)
    #turtle.pendown()
    angle = angle + 50
    length = length + 10
    for x in range(quantity):
        turtle.circle(radius)
    radius = radius - quantity
    if(radius > 5):
        recursive_circles(turtle, angle, length, quantity, delta, radius)

def main():
    ANIMATION_SPEED = 0.0
    raphael = Turtle()
    raphael.speed(ANIMATION_SPEED)
    recursive_circles(raphael, 25, 10, 1, 2, 150)

main()