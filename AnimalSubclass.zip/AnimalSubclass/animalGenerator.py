import random
from Animal import Animal, Bird, Mammal

def animal_type():
    a_type = input("What type of animal would you like to create? ")
    return a_type

def animal_name():
    a_name = input("What is the animal's name? ")
    return a_name

def animal_hair_color():
    a_color = input("What is the mammal's hair color?")
    return a_color

def animal_can_fly():
    fly = input("Can this bird fly? ")
    return fly

def main():
    print("Welcome to the animal generator!\nThis program creates Animal objects.\n")
    list = []
    creating_animal = True
    while(creating_animal):
        class_type = int(input("Would you like to create a Bird or a Mammal?\n1. Mammal\n2. Bird\nWhich would you like to create? "))
        if(class_type == 1):     
            _type = animal_type()
            _name = animal_name()
            _hair_color = animal_hair_color()
            _mood = ""

            Mammals = Mammal(_type, _name, _mood, _hair_color)
            

            a_name = Mammals.get_name(_name)
            a_type = Mammals.get_animal_type(_type)
            a_mood = Mammals.check_mood(_mood)

            list.append(a_name + " the " + a_type + " is " + a_mood)
        
        if(class_type == 2):
            _type = animal_type()
            _name = animal_name()
            _can_fly = animal_can_fly()
            _mood = ""

            Birds = Bird(_type, _name, _mood, _can_fly)
            

            a_name = Birds.get_name(_name)
            a_type = Birds.get_animal_type(_type)
            a_mood = Birds.check_mood(_mood)

            list.append(a_name + " the " + a_type + " is " + a_mood)

        do_again = input("Would you like to add more animals (y/n)? ")
        if(do_again != 'y'):
            creating_animal = False
        
    print("\n")
    print("Animal List:")
    for obj in list:
        print(obj)
main()