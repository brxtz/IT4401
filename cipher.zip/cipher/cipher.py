cipher = dict({
    'a': '0', 'b': '1', 'c': '2', 'd': '3', 'e': '4', 'f': '5', 'g': '6', 'h': '7', 'i': '8', 'j': '9',
    'k': '!', 'l': '@', 'm': '#', 'n': '$', 'o': '%', 'p': '^', 'q': '&', 'r': '*', 's': '(', 't': ')',
    'u': '-', 'v': '+', 'w': '<', 'x': '>', 'y': '?', 'z': '='
})

def encoder(message):
    changed_message = ''
    for i in range(0, len(message)):
        if message[i] in cipher.keys():
            changed_message += cipher[message[i]]
        else:
            changed_message += message[i]
    return changed_message

def decoder(message):
    changed_message = ''
    for i in range(0, len(message)):
        if message[i] == ' ':
            changed_message += ' '
        for value in cipher:
            if cipher[value] == message[i]:
                changed_message += value
            else:
                pass
    return changed_message

def main():
    print("Welcome to the Secret Message Encoder/Decoder\n")
    run_program = True
    while run_program:
        try:
            options = int(input("1. Encode a message\n2. Decode a message\n3.Exit\n\nWhat would you like to do? "))
            if (options == 1):
                encode = input("Enter a message to encode: ")
                encoded_message = encoder(encode)
                print("Encoded message: ", encoded_message)
                run_again = input("Would you like to run the program again?(y/n) ")
                if run_again != 'y':
                    run_program = False
                else:
                    continue              
            if (options == 2):
                decode = input("Enter a message to decode: ")
                decoded_message = decoder(decode)
                print('Decoded message: ', decoded_message)
                run_again = input("Would you like to run the program again?(y/n) ")
                if run_again != 'y':
                    run_program = False
            else:
                break
        except Exception as err:
            print("There was an error: ", err)
            print("Please start over.\n")

main()