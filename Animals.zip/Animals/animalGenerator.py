import random
from Animal import Animal

def animal_type():
    a_type = input("What type of animal would you like to create? ")
    return a_type

def animal_name():
    a_name = input("What is the animal's name? ")
    return a_name

def main():
    print("Welcome to the animal generator!\nThis program creates Animal objects.\n")
    list = []
    creating_animal = True
    while(creating_animal):
        _type = animal_type()
        _name = animal_name()
        _mood = ""

        Animals = Animal(_type, _name, _mood)
        

        a_name = Animals.get_name(_name)
        a_type = Animals.get_animal_type(_type)
        a_mood = Animals.check_mood(_mood)

        list.append(a_name + " the " + a_type + " is " + a_mood)


        do_again = input("Would you like to add more animals (y/n)? ")
        if(do_again != 'y'):
            creating_animal = False
        
    print("\n")
    print("Animal List:")
    for obj in list:
        print(obj)
main()