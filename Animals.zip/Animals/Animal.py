import random

class Animal:

    def __init__(self, __animal_type, __name, __mood):

        self.__animal_type = __animal_type
        self.__name = __name
        mood_status = random.randint(1, 3)
        if(mood_status == 1):
            self.__mood = "happy"
        if(mood_status == 2):
            self.__mood = "hungry"
        if(mood_status == 3):
            self.__mood = "sleepy"  

    def get_animal_type(self, __animal_type):
        return self.__animal_type
    
    def get_name(self, __name):
        return self.__name

    def check_mood(self, __mood):
        return self.__mood
                
