def get_file():
    numbers = []
    try:
        f = open("numbers.txt", "r")
        for x in f:
            numbers.append(int(x))
        f.close()
    except FileNotFoundError:
        print("Error: File couldn't open. Check to see if the file exists.")

    return numbers

def file_count(numbers):
    count = 0
    for x in numbers:
        count += 1
    return count

def file_sum(numbers):
    sum = 0
    for x in numbers:
        sum += x
    return sum

def file_average(sum, count):
    return sum / count

def file_maximum(numbers):
    return max(numbers)

def file_minimum(numbers):
    return min(numbers)

def file_range(max, min):
    return max - min

def get_stats():
    numbers = get_file()
    count = file_count(numbers)
    sum = file_sum(numbers)
    average = file_average(sum, count)
    max = file_maximum(numbers)
    min = file_minimum(numbers)
    range = file_range(max, min)

    print("Sum = %d" % sum)
    print("Count = %d" % count)
    print("Average = %.1f" % average)
    print("Maximun = %d" % max)
    print("Minimun = %d" % min)
    print("Range = %d" % range)

def main():
    print("File name: numbers.txt\n")
    get_stats()

main()
    
