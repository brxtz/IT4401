def main():
    print("List of random numbers in randomnun.txt:\n")
    count = 0   
    try:
        f = open("randomnum.txt", "r")            
        for x in f:
            print(x)
            count += 1
                
        f.close()
        print("Random numbers count: %d" % count)
    except FileNotFoundError:
        print("Error: The file couldn't be opened. Check to see if the file exists.")
        
            
main()
