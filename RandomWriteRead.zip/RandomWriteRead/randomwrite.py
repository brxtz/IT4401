import random


#function that will return the number of random numbers the user wants to have in the file
def get_count():
    count = 0
    while(True):
        try:
            count = int(input("How many random numberrs would you like to generate? "))
            if(count <= 0):
                print("Only positive numbers are allowed.")
                continue       
        except:
            print("Error: The value entered is invalid.\n Please enter a valid value.")
        else:
            break
    return count

#function that will return the file's lowest number 
def get_lower_bound():
    lowest = 0
    while(True):
        try:
            lowest = int(input("What the lowest random number should be? "))
            if(lowest <= 0):
                print("Only positive numbers are allowed.") 
                continue 
        except:
            print("Error: The value entered is invalid.\n Please enter a valid value.")
        else:
            break
    return lowest

#function that will return the file's highest number
def get_upper_bound():
    highest = 0
    while(True):
        try:
            highest = int(input("What the highest random number should be? "))
            if(highest <= 0):
                print("Only positive numbers are allowed.")  
                continue
        except:
            print("Error: The value entered is invalid.\n Please enter a valid value.")
        else: 
            break
    return highest

#function that will create the new file called randomnum.txt
def create_file(count, lowest, highest):
    f = open("randomnum.txt", "w")

    f.write(str(lowest))
    f.write("\n")

    for x in range(count-2):
        f.write(str(random.randint(lowest + 1, highest - 1)))
        f.write("\n")

    f.write(str(highest))
    f.write("\n")
    
    f.close()
    print("The random numbers were written to randomnum.txt")

def get_file():
    count = get_count()
    lowest = get_lower_bound()
    highest = get_upper_bound()

    create_file(count, lowest, highest) 

def main():
    print("Random Number File Writer")
    while(True):
        print('')
        get_file()      
        another_file = input("\nWould you like to do a new file? (y/n) ")
        if(another_file != 'y'):
            break

main()






